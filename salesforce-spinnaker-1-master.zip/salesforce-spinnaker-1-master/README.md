## Training schedule 

<img src="sch.png">

