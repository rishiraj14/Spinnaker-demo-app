# Architecture 

## major components are listed below 

<img src="images/components.png">

### Connections and workflow of components 

<img src="images/flow.png">

### system dependencies of Spinnaker

<img src="images/dependency.png">

### some important port numbers 

<img src="images/ports.png">


