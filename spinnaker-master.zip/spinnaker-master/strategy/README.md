## spinnaker support many application Deployment strategy 

### type of strategy 

<img src="str.png">


