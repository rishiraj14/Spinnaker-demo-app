## Deploy to aws 

### Understanding managed and managing account 

### managing 

<p>THe spinnaker account used to login into aws </p>

### managed

<p>THe spinnaker will modify resources  </p>
