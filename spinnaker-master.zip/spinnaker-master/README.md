# spinnaker

<p>
Spinnaker is an open-source, multi-cloud continuous delivery platform that helps you release software changes with high velocity and confidence.
</p>

## info about Spinnaker 

<ol>
  <li>Started By Netflix in 2014 </li>
  <li>OpenSourced in November 2015  </li>
  <li> Backed by Netflix , Google , Microsoft etc ..</li>
</ol>


### What is Spinnaker 

<img src="images/what.png">

### Reasons for using spinnaker 

<img src="images/why.png">

### stage in deployment which is gonna be best fit to use spinnaker 

<img src="images/use.png">

### one of the implementations 

<img src="images/case1.png">


